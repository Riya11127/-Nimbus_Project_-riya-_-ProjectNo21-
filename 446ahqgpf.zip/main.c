#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[50];
    int power;              // in watts
} Appliance;

typedef struct {
    int applianceIndex;     
    float hoursUsed;        // per day
    int days;               // number of days used
} UsageEntry;

Appliance *appliances = NULL;
UsageEntry *logs = NULL;
int applianceCount = 0, logCount = 0;

// ---------------- Function Declarations ----------------
void addAppliance();
void addUsageEntry();
void viewReport();
float computeEnergyKWh(int logIndex);
void topThreeAppliances();
void monthlyTotals();

// ---------------- Add Appliance ----------------
void addAppliance() {
    appliances = realloc(appliances, (applianceCount + 1) * sizeof(Appliance));

    printf("\nEnter Appliance Name: ");
    scanf("%s", appliances[applianceCount].name);

    printf("Enter Power Rating (Watts): ");
    scanf("%d", &appliances[applianceCount].power);

    applianceCount++;
    printf("\nAppliance Added Successfully!\n");
}

// ---------------- Add Usage Entry ----------------
void addUsageEntry() {
    if (applianceCount == 0) {
        printf("\nNo appliances found! Add appliances first.\n");
        return;
    }

    logs = realloc(logs, (logCount + 1) * sizeof(UsageEntry));

    printf("\nSelect Appliance:\n");
    for (int i = 0; i < applianceCount; i++)
        printf("%d. %s (%dW)\n", i, appliances[i].name, appliances[i].power);

    printf("Enter index: ");
    scanf("%d", &logs[logCount].applianceIndex);

    printf("Hours used per day: ");
    scanf("%f", &logs[logCount].hoursUsed);

    printf("Days used: ");
    scanf("%d", &logs[logCount].days);

    logCount++;
    printf("\nUsage Entry Added!\n");
}

// ---------------- Energy Calculation (kWh) ----------------
float computeEnergyKWh(int logIndex) {
    UsageEntry u = logs[logIndex];
    Appliance a = appliances[u.applianceIndex];

    float kWh = (a.power / 1000.0) * u.hoursUsed * u.days;
    return kWh;
}

// ---------------- Monthly Totals ----------------
void monthlyTotals() {
    if (logCount == 0) {
        printf("\nNo usage logs available!\n");
        return;
    }

    printf("\n--- Monthly Total Consumption per Appliance ---\n");
    for (int i = 0; i < applianceCount; i++) {
        float total = 0;
        for (int j = 0; j < logCount; j++) {
            if (logs[j].applianceIndex == i)
                total += computeEnergyKWh(j);
        }
        printf("%s: %.2f kWh\n", appliances[i].name, total);
    }
}

// ---------------- Top 3 Consuming Appliances ----------------
void topThreeAppliances() {
    float *consumption = calloc(applianceCount, sizeof(float));

    for (int i = 0; i < logCount; i++) {
        consumption[logs[i].applianceIndex] += computeEnergyKWh(i);
    }

    printf("\n--- Top 3 Highest Consuming Appliances ---\n");

    for (int k = 0; k < 3; k++) {
        int maxIdx = -1;
        float maxVal = -1;

        for (int i = 0; i < applianceCount; i++) {
            if (consumption[i] > maxVal) {
                maxVal = consumption[i];
                maxIdx = i;
            }
        }

        if (maxIdx != -1 && maxVal > 0) {
            printf("%d) %s : %.2f kWh\n", k + 1, appliances[maxIdx].name, maxVal);
            consumption[maxIdx] = -1;  // prevent re-selection
        }
    }

    free(consumption);
}

// ---------------- Main Report ----------------
void viewReport() {
    if (logCount == 0) {
        printf("\nNo usage entries found!\n");
        return;
    }

    monthlyTotals();
    topThreeAppliances();
}

// ---------------- Main Menu ----------------
int main() {
    int choice;

    while (1) {
        printf("\n\n===== SMART ENERGY CONSUMPTION ANALYZER =====\n");
        printf("1. Add Appliance\n");
        printf("2. Add Daily Usage Entry\n");
        printf("3. View Reports\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: addAppliance(); break;
            case 2: addUsageEntry(); break;
            case 3: viewReport(); break;
            case 4: 
                printf("\nExiting...\n");
                exit(0);
            default: printf("\nInvalid Choice!\n");
        }
    }
    return 0;
}
